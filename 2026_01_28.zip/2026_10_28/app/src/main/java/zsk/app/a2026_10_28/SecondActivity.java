package zsk.app.a2026_10_28;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class SecondActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_second);
    }
    public void onClick(View view) {
        EditText imie = findViewById(R.id.imie);
        EditText email = findViewById(R.id.email);
        EditText haslo = findViewById(R.id.haslo);

        String imieStr = imie.getText().toString();
        String emailStr = email.getText().toString();
        String hasloStr = haslo.getText().toString();

        boolean imieBoob = true;
        boolean emailBoob = true;
        boolean hasloBoob = true;

        if(imieStr.isEmpty()){
            imieBoob = false;
            Toast.makeText(this, "Brak imienia", Toast.LENGTH_SHORT).show();
        }
        if(!emailStr.contains("@")){
            emailBoob = false;
            Toast.makeText(this, "Brak @ w email", Toast.LENGTH_SHORT).show();
        }
        if(!hasloStr.matches("^(?=.*[a-z])(?=.*[A-Z])(?=.*\\d).*$")){
            hasloBoob = false;
            Toast.makeText(this, "Za słabe hasło", Toast.LENGTH_SHORT).show();
        }

        if(imieBoob && emailBoob && hasloBoob){
            Intent intent = new Intent();
            intent.putExtra("imie", imieStr);
            setResult(RESULT_OK, intent);
            finish();
        }
    }
}