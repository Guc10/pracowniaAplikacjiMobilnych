package zsk.app.formularz;

import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.fragment.app.Fragment;

import java.util.ArrayList;

public class Form extends Fragment {
    public static ArrayList<String> bugs = new ArrayList<>();

    private void addBug(String message) {
        bugs.add(message);
        Bugs bugsFragment = (Bugs) getParentFragmentManager().findFragmentById(R.id.fragment2);
        if (bugsFragment != null && bugsFragment.adapter != null) {
            bugsFragment.adapter.notifyDataSetChanged();
        }
    }

    public boolean isValidPesel(String pesel) {

        if (pesel == null || pesel.length() != 11) {
            return false;
        }

        int[] weights = {1,3,7,9,1,3,7,9,1,3};
        int sum = 0;

        for (int i = 0; i < 10; i++) {
            int digit = Character.getNumericValue(pesel.charAt(i));
            sum += digit * weights[i];
        }

        int control = (10 - (sum % 10)) % 10;
        int lastDigit = Character.getNumericValue(pesel.charAt(10));

        return control == lastDigit;
    }

    @Override
    public View onCreateView(LayoutInflater inflater, ViewGroup container, Bundle
            savedInstanceState) {
        View view = inflater.inflate(R.layout.form, container, false);
        Register activity = (Register) getActivity();

        EditText mail = view.findViewById(R.id.mail);
        EditText pass1 = view.findViewById(R.id.pass1);
        EditText pass2 = view.findViewById(R.id.pass2);
        EditText pesel = view.findViewById(R.id.pesel);
        Button button = view.findViewById(R.id.button1);
        Button exit = view.findViewById(R.id.button2);

        button.setOnClickListener(v -> {
            boolean isCorrect = true;
            bugs.clear();
            String mailText = mail.getText().toString();
            String pass1Text = pass1.getText().toString();
            String pass2Text = pass2.getText().toString();
            String peselText = pesel.getText().toString();

            if (mailText.isEmpty() || pass1Text.isEmpty() || pass2Text.isEmpty() || peselText.isEmpty()) {
                addBug("All fields must be filled");
                isCorrect = false;
            }

            if (!mailText.contains("@")) {
                addBug("Invalid email address");
                isCorrect = false;
            }

            if (!pass1Text.equals(pass2Text)) {
                addBug("Passwords do not match");
                isCorrect = false;
            }

            // pesel confirmation code
            if (!isValidPesel(peselText)) {
                addBug("Invalid PESEL number");
                isCorrect = false;
            }

            if (activity != null && isCorrect) {
                Register.users.add(new User(mailText, pass1Text, peselText));
                Toast.makeText(getActivity(), "Registration successful", Toast.LENGTH_SHORT).show();
                activity.finish();
            }else{
                return;
            }
        });

        exit.setOnClickListener(v -> {
            getActivity().finish();
        });

        return view;
    }
}
