package zsk.app.formularz;

import static zsk.app.formularz.Register.users;

import android.content.Intent;
import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Login extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.login);

        EditText mail = findViewById(R.id.mail);
        EditText password = findViewById(R.id.pass);
        Button button1 = findViewById(R.id.button1);
        Button button2 = findViewById(R.id.button2);

        button1.setOnClickListener(v -> {
            String mailText = mail.getText().toString();
            String passwordText = password.getText().toString();

            User found = users.stream()
                    .filter(u -> u.email.equals(mailText) && u.password.equals(passwordText))
                    .findFirst()
                    .orElse(null);

            if (found == null) {
                Toast.makeText(Login.this, "Invalid email or password", Toast.LENGTH_SHORT).show();
                return;
            }

            Intent intent = new Intent(Login.this, Logged.class);
            intent.putExtra("email", mailText);
            startActivity(intent);
        });

        button2.setOnClickListener(v -> {
            Intent intent = new Intent(Login.this, Register.class);
            startActivity(intent);
        });
    }
}