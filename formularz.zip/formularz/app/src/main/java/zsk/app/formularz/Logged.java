package zsk.app.formularz;

import android.os.Bundle;
import android.widget.Button;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

public class Logged extends AppCompatActivity {
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.logged);

        String username = getIntent().getStringExtra("email");
        Toast.makeText(Logged.this, "Welcome: " + username, Toast.LENGTH_SHORT).show();
        Button button1 = findViewById(R.id.button1);

        button1.setOnClickListener(v -> {
            finish();
        });
    }
}
