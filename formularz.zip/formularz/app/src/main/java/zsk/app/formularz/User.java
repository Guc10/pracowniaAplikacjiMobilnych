package zsk.app.formularz;

public class User {
    public String email;
    public String password;
    public String pesel;

    public User(String email, String password, String pesel) {
        this.email = email;
        this.password = password;
        this.pesel = pesel;
    }
}
