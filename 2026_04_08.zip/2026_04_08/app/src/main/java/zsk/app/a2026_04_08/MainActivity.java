package zsk.app.a2026_04_08;

import android.os.Bundle;

import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.content.Context;
import android.os.Build;
import android.os.Bundle;
import android.view.View;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

public class MainActivity extends AppCompatActivity {

    private static final String CHANNEL_LOW      = "channel_low";
    private static final String CHANNEL_DEFAULT  = "channel_default";
    private static final String CHANNEL_HIGH     = "channel_high";

    // Każdy poziom ma osobny licznik ID — dzięki temu powiadomienia się stackują
    private int idLow     = 1000;
    private int idDefault = 2000;
    private int idHigh    = 3000;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        createNotificationChannels();

        findViewById(R.id.btnLow).setOnClickListener(v ->
                sendNotification(
                        CHANNEL_LOW,
                        idLow++,
                        "Powiadomienie niskie",
                        "To jest powiadomienie o niskim priorytecie (#" + (idLow - 1000) + ")",
                        NotificationCompat.PRIORITY_LOW
                )
        );

        findViewById(R.id.btnDefault).setOnClickListener(v ->
                sendNotification(
                        CHANNEL_DEFAULT,
                        idDefault++,
                        "Powiadomienie domyślne",
                        "To jest powiadomienie o domyślnym priorytecie (#" + (idDefault - 2000) + ")",
                        NotificationCompat.PRIORITY_DEFAULT
                )
        );

        findViewById(R.id.btnHigh).setOnClickListener(v ->
                sendNotification(
                        CHANNEL_HIGH,
                        idHigh++,
                        "Powiadomienie wysokie",
                        "To jest powiadomienie o wysokim priorytecie (#" + (idHigh - 3000) + ")",
                        NotificationCompat.PRIORITY_HIGH
                )
        );
    }

    private void createNotificationChannels() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            NotificationManager manager =
                    (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);

            // Kanał niski
            NotificationChannel channelLow = new NotificationChannel(
                    CHANNEL_LOW,
                    "Niski priorytet",
                    NotificationManager.IMPORTANCE_LOW
            );
            channelLow.setDescription("Powiadomienia o niskim priorytecie");

            // Kanał domyślny
            NotificationChannel channelDefault = new NotificationChannel(
                    CHANNEL_DEFAULT,
                    "Domyślny priorytet",
                    NotificationManager.IMPORTANCE_DEFAULT
            );
            channelDefault.setDescription("Powiadomienia o domyślnym priorytecie");

            // Kanał wysoki
            NotificationChannel channelHigh = new NotificationChannel(
                    CHANNEL_HIGH,
                    "Wysoki priorytet",
                    NotificationManager.IMPORTANCE_HIGH
            );
            channelHigh.setDescription("Powiadomienia o wysokim priorytecie");

            manager.createNotificationChannel(channelLow);
            manager.createNotificationChannel(channelDefault);
            manager.createNotificationChannel(channelHigh);
        }
    }

    private void sendNotification(String channelId, int notifId,
                                  String title, String text, int priority) {
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, channelId)
                .setSmallIcon(android.R.drawable.ic_dialog_info)
                .setContentTitle(title)
                .setContentText(text)
                .setPriority(priority)
                .setAutoCancel(true);

        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(this);

        // Sprawdzenie uprawnienia (wymagane od Android 13 / API 33)
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU
                || checkSelfPermission(android.Manifest.permission.POST_NOTIFICATIONS)
                == android.content.pm.PackageManager.PERMISSION_GRANTED) {
            notificationManager.notify(notifId, builder.build());
        } else {
            requestPermissions(
                    new String[]{android.Manifest.permission.POST_NOTIFICATIONS}, 1);
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode,
                                           String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        // Po przyznaniu uprawnienia użytkownik może ponownie nacisnąć przycisk
    }
}