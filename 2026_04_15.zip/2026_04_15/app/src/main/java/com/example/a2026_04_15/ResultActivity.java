package com.example.a2026_04_15;

import android.app.NotificationManager;
import android.content.Context;
import android.os.Bundle;
import android.widget.TextView;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.RemoteInput;

public class ResultActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_result);

        TextView resultTextView = findViewById(R.id.resultTextView);

        NotificationManager notificationManager = (NotificationManager) getSystemService(Context.NOTIFICATION_SERVICE);
        notificationManager.cancel(101); // NOTIFICATION_ID z MainActivity

        Bundle remoteInput = RemoteInput.getResultsFromIntent(getIntent());
        if (remoteInput != null) {
            String userTranslation = remoteInput.getCharSequence(MainActivity.KEY_TEXT_REPLY).toString();
            String correctTranslation = getIntent().getStringExtra("correct_translation");
            String polishWord = getIntent().getStringExtra("polish_word");

            if (userTranslation.equalsIgnoreCase(correctTranslation)) {
                resultTextView.setText("Brawo! Poprawne tłumaczenie słowa '" + polishWord + "' to '" + correctTranslation + "'.");
            } else {
                resultTextView.setText("Niestety, błąd. Słowo '" + polishWord + "' to po angielsku '" + correctTranslation + "', a Ty wpisałeś '" + userTranslation + "'.");
            }
        }
    }
}
