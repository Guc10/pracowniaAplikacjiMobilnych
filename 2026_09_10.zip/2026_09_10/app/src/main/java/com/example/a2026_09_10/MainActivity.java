package com.example.a2026_09_10;

import android.os.Bundle;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.EditText;
import android.widget.ListView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity {

    private ListView listView;
    private ArrayList<String> activityList;
    private ArrayAdapter<String> adapter;
    private ArrayList<Integer> activityTimes; // Przechowuje czas w minutach od początku dnia

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        listView = findViewById(R.id.listView);
        activityList = new ArrayList<>();
        activityTimes = new ArrayList<>();
        adapter = new ArrayAdapter<>(this, android.R.layout.simple_list_item_1, activityList);
        listView.setAdapter(adapter);
    }

    public void dodaj(View view) {
        EditText dataEditText = findViewById(R.id.Data);
        EditText aktywnoscEditText = findViewById(R.id.Aktywnosc);

        String data = dataEditText.getText().toString().trim();
        String aktywnosc = aktywnoscEditText.getText().toString().trim();

        if (data.isEmpty() || aktywnosc.isEmpty()) {
            Toast.makeText(this, "Wypełnij wszystkie pola", Toast.LENGTH_SHORT).show();
            return;
        }

        try {
            String[] parts = data.split(":");
            if (parts.length != 2) {
                Toast.makeText(this, "Niepoprawny format godziny (Użyj HH:mm)", Toast.LENGTH_SHORT).show();
                return;
            }
            int hour = Integer.parseInt(parts[0].trim());
            int minute = Integer.parseInt(parts[1].trim());

            if (hour < 0 || hour > 23 || minute < 0 || minute > 59) {
                Toast.makeText(this, "Niepoprawna godzina", Toast.LENGTH_SHORT).show();
                return;
            }

            int newMinutes = hour * 60 + minute;

            boolean isConflict = false;
            for (int existingMinutes : activityTimes) {
                int diff = Math.abs(newMinutes - existingMinutes);
                int circularDiff = Math.min(diff, 1440 - diff);
                if (circularDiff <= 30) {
                    isConflict = true;
                    break;
                }
            }

            if (isConflict) {
                Toast.makeText(this, "Aktywność w przeciągu +-30 minut już istnieje!", Toast.LENGTH_SHORT).show();
            } else {
                activityTimes.add(newMinutes);
                activityList.add(data + " - " + aktywnosc);
                adapter.notifyDataSetChanged();

                aktywnoscEditText.setText("");
            }
        } catch (NumberFormatException e) {
            Toast.makeText(this, "Niepoprawny format godziny", Toast.LENGTH_SHORT).show();
        }
    }
}