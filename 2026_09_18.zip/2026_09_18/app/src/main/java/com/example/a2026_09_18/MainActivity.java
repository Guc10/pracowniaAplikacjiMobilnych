package com.example.a2026_09_18;

import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ListView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    String text;
    String name;
    String specie;
    String goal;
    String time;
    int age;

    SeekBar seekBar;
    ListView listView;
    Button button;
    TextView ageValue;
    TextView nameValue;
    TextView goalValue;
    TextView timeValue;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });

        seekBar = findViewById(R.id.seekBar);
        seekBar.setProgress(0);
        seekBar.setMax(20);

        listView = findViewById(R.id.listView);
        button = findViewById(R.id.button);
        ageValue = findViewById(R.id.ageValue);
        nameValue = findViewById(R.id.nameValue);
        goalValue = findViewById(R.id.goalValue);
        timeValue = findViewById(R.id.timeValue);

        seekBar.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                age = progress;
                ageValue.setText(String.valueOf(progress));
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {

            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {

            }
        });

        listView.setOnItemClickListener((parent, view, position, id) -> {
            String selectedPet = (String) parent.getItemAtPosition(position);

            if (selectedPet.equals("Pies")) {
                seekBar.setMax(18);
                specie = "pies";
            } else if (selectedPet.equals("Kot")) {
                seekBar.setMax(20);
                specie = "Kot";
            } else if (selectedPet.equals("Świnka morska")) {
                seekBar.setMax(9);
                specie = "Świnka morska";
            }
        });
    }

    public void onClick(View view){
        name = nameValue.getText().toString();
        nameValue.setText("");
        goal = goalValue.getText().toString();
        goalValue.setText("");
        time = timeValue.getText().toString();
        timeValue.setText("");

        text = name + ", " + specie + ", " + age + " lat, " + goal + ", " + time;

        Toast toast = Toast.makeText(view.getContext(), text, Toast.LENGTH_SHORT);
        toast.show();
    }
}