package com.example.a2026_09_11;

import android.os.Bundle;
import android.view.View;
import android.widget.CheckBox;
import android.widget.EditText;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.activity.EdgeToEdge;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.graphics.Insets;
import androidx.core.view.ViewCompat;
import androidx.core.view.WindowInsetsCompat;

public class MainActivity extends AppCompatActivity {

    EditText imieView;
    EditText emailView;
    EditText passwordView;
    RadioGroup genderGroup;
    CheckBox termsCheckBox;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        EdgeToEdge.enable(this);
        setContentView(R.layout.activity_main);

        imieView = findViewById(R.id.imie);
        emailView = findViewById(R.id.email);
        passwordView = findViewById(R.id.password);
        genderGroup = findViewById(R.id.radioGroup);
        termsCheckBox = findViewById(R.id.checkBox);

        ViewCompat.setOnApplyWindowInsetsListener(findViewById(R.id.main), (v, insets) -> {
            Insets systemBars = insets.getInsets(WindowInsetsCompat.Type.systemBars());
            v.setPadding(systemBars.left, systemBars.top, systemBars.right, systemBars.bottom);
            return insets;
        });
    }

    public void register(View view) {
        String imie = imieView.getText().toString();
        String email = emailView.getText().toString();
        String password = passwordView.getText().toString();
        String plec = genderGroup.getCheckedRadioButtonId() == R.id.man ? "Mężczyzna" : "Kobieta";
        boolean isGenderSelected = genderGroup.getCheckedRadioButtonId() != -1;
        boolean isTermsAccepted = termsCheckBox.isChecked();

        if (imie.isEmpty() || email.isEmpty() || password.isEmpty()) {
            Toast.makeText(this, "Wszystkie pola tekstowe muszą być uzupełnione", Toast.LENGTH_SHORT).show();
        } else if (!isGenderSelected) {
            Toast.makeText(this, "Proszę wybrać płeć", Toast.LENGTH_SHORT).show();
        } else if (!isTermsAccepted) {
            Toast.makeText(this, "Musisz zaakceptować regulamin", Toast.LENGTH_SHORT).show();
        } else {
            Toast.makeText(this, "Rejestracja przebiegła pomyślnie dla użytkownika: " + imie + " " + plec, Toast.LENGTH_SHORT).show();
            cancel(view);
        }
    }

    public void cancel(View view) {
        imieView.setText("");
        emailView.setText("");
        passwordView.setText("");
        genderGroup.clearCheck();
        termsCheckBox.setChecked(false);
    }
}